# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""
default_app_config = 'apps.home.config.MyConfig'